fx_version 'adamant'
games { 'gta5' };
client_scripts {
        'cl.lua',
}
server_scripts {
        '@mysql-async/lib/MySQL.lua',
        'config.lua',
        'sv.lua',
}
