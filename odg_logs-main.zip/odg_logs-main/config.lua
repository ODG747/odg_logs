Webhook = {
    Name = "odg_logs",
    Logo = "https://media.discordapp.net/attachments/743953072266412056/744662695541735504/CoreoLogo.png",
    ShowIp = true,
    Chan = {
        -- Logs --
        ["Serveur ON/OFF"] = "tonwebhookici",
        ["Connnections"] = "tonwebhookici",
        ["Kill"] = "tonwebhookici",
        ["Items"] = "tonwebhookici",
        ["Cash"] = "tonwebhookici",
        ["Armes"] = "tonwebhookici",
        ["Véhicules"] = "tonwebhookici",
        ["Staff"] = "tonwebhookici",
        ["Illégals"] = "tonwebhookici",
        ["Jobs"] = "tonwebhookici",
    },
    Color = {
        ["Blue"] = 3447003,
        ["Red"] = 15158332,
        ["Green"] = 3066993,
        ["Yellow"] = 15844367,
        ["Grey"] = 9807270,
        ["Purple"] = 10181046,
    },
}
